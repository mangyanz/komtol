<?php 
$nik = "WEB CAHYO SR II";
$sender = "jgndiganggu@paket23y.terbaru-link.me";
?>